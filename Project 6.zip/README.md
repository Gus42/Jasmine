# Project Overview



How to run the app:
- Open index.html in your browser. (right-click on index.html -> open with -> select your browser: Chrome, Firefox, Safari..)
